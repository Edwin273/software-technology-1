from keras.datasets import mnist

# load dataset
(train_images, train_labels), (test_images, test_labels) = mnist.load_data()

# print shape
print('Train images:', train_images.shape)
print('Train labels:', train_labels.shape)

print('Test images:', test_images.shape)
print('Test labels:', test_labels.shape)

# print pixel statistics
print('Train min:', train_images.min())
print('Train max:', train_images.max())
print('Train mean:', train_images.mean())
print('Train std:', train_images.std())

print('Test min:', test_images.min())
print('Test max:', test_images.max())
print('Test mean:', test_images.mean())
print('Test std:', test_images.std())