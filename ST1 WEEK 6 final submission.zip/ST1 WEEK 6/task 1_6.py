from keras.datasets import mnist
from tensorflow.keras.preprocessing.image import ImageDataGenerator

# load dataset
(trainX, trainY), (testX, testY) = mnist.load_data()

# reshape dataset
trainX = trainX.reshape((trainX.shape[0], 28, 28, 1))
testX = testX.reshape((testX.shape[0], 28, 28, 1))

# print original mean
print('Before centering:')
print('Train mean=%.3f' % trainX.mean())
print('Test mean=%.3f' % testX.mean())

# create generator for centering
datagen = ImageDataGenerator(featurewise_center=True)

# compute mean from training data
datagen.fit(trainX)

# apply transformation
iterator = datagen.flow(trainX, trainY, batch_size=64)
batchX, batchY = next(iterator)

print('\nAfter centering:')
print('Batch mean=%.3f' % batchX.mean())