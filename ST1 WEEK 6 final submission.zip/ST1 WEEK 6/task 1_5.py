from keras.datasets import mnist
from tensorflow.keras.preprocessing.image import ImageDataGenerator

# load dataset
(trainX, trainY), (testX, testY) = mnist.load_data()

# reshape to add channel (important)
trainX = trainX.reshape((trainX.shape[0], 28, 28, 1))
testX = testX.reshape((testX.shape[0], 28, 28, 1))

# print before normalization
print('Before normalization:')
print('Train min=%.3f, max=%.3f' % (trainX.min(), trainX.max()))
print('Test min=%.3f, max=%.3f' % (testX.min(), testX.max()))

# normalize using ImageDataGenerator
datagen = ImageDataGenerator(rescale=1.0/255.0)

train_iterator = datagen.flow(trainX, trainY, batch_size=64)
test_iterator = datagen.flow(testX, testY, batch_size=64)

# check one batch
batchX, batchY = next(train_iterator)

print('\nAfter normalization:')
print('Batch shape:', batchX.shape)
print('Min=%.3f, Max=%.3f' % (batchX.min(), batchX.max()))