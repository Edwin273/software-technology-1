import matplotlib.pyplot as plt
from keras.preprocessing.image import load_img

# load the image
img_path = '/content/image.PNG'
img = load_img(img_path)

# report details about the image
print(type(img))
print(img.format)
print(img.mode)
print(img.size)

# display the image
plt.imshow(img)
plt.axis('off')
plt.show()