from keras.datasets import mnist
from tensorflow.keras.preprocessing.image import ImageDataGenerator

# load dataset
(trainX, trainY), (testX, testY) = mnist.load_data()

# reshape dataset
trainX = trainX.reshape((trainX.shape[0], 28, 28, 1))
testX = testX.reshape((testX.shape[0], 28, 28, 1))

# print original stats
print('Before standardization:')
print('Train mean=%.3f, std=%.3f' % (trainX.mean(), trainX.std()))

# create generator
datagen = ImageDataGenerator(featurewise_center=True, featurewise_std_normalization=True)

# fit generator
datagen.fit(trainX)

# apply transformation
iterator = datagen.flow(trainX, trainY, batch_size=64)
batchX, batchY = next(iterator)

print('\nAfter standardization:')
print('Batch mean=%.3f' % batchX.mean())
print('Batch std=%.3f' % batchX.std())